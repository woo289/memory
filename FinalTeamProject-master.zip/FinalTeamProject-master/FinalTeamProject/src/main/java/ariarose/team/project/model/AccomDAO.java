package ariarose.team.project.model;

import java.util.List;

import ariarose.team.project.vo.AccomVO;

public interface AccomDAO {
	public List<AccomVO> getListAccom(AccomVO vo);
}
